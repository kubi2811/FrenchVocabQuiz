import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Quiz-related types
export const quizQuestionSchema = z.object({
  word: z.string(),
  sentence: z.string(),
  question: z.string(),
  options: z.array(z.string()).length(4),
  answer: z.string(),
  level: z.enum(["A1", "A2", "B1", "B2", "C1"]),
  type: z.enum(["english_to_french", "french_to_english", "french_fill_blank"]).default("english_to_french"),
});

export const quizResultSchema = z.object({
  level: z.enum(["A1", "A2", "B1", "B2", "C1"]),
  score: z.number(),
  totalQuestions: z.number(),
  answers: z.array(z.object({
    questionIndex: z.number(),
    userAnswer: z.string(),
    correctAnswer: z.string(),
    isCorrect: z.boolean(),
    word: z.string(),
  })),
  timeTaken: z.number(),
});

export type QuizQuestion = z.infer<typeof quizQuestionSchema>;
export type QuizResult = z.infer<typeof quizResultSchema>;
export type DelLevel = "A1" | "A2" | "B1" | "B2" | "C1";

// Vocabulary tracking schemas
export const vocabularyItemSchema = z.object({
  word: z.string(),
  meaning: z.string(),
  level: z.enum(["A1", "A2", "B1", "B2", "C1"]),
  status: z.enum(["just_learned", "very_learned"]),
  correctAnswers: z.number().default(0),
  incorrectAnswers: z.number().default(0),
  firstSeenAt: z.number(),
  lastSeenAt: z.number(),
  lastAnsweredAt: z.number().optional(),
});

export const vocabularyStatsSchema = z.object({
  justLearned: z.number(),
  veryLearned: z.number(),
  totalWords: z.number(),
  byLevel: z.record(z.object({
    justLearned: z.number(),
    veryLearned: z.number(),
  })),
});

export type VocabularyItem = z.infer<typeof vocabularyItemSchema>;
export type VocabularyStats = z.infer<typeof vocabularyStatsSchema>;
