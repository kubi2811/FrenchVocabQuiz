import { DelLevel, QuizQuestion } from "@shared/schema";

// This file contains utility functions for quiz data management
export const QUIZ_LEVELS: DelLevel[] = ["A1", "A2", "B1", "B2", "C1"];

export const LEVEL_DESCRIPTIONS = {
  A1: {
    title: "Beginner",
    description: "Basic vocabulary for everyday situations",
    duration: 5,
  },
  A2: {
    title: "Elementary", 
    description: "Expanded vocabulary for common topics",
    duration: 5,
  },
  B1: {
    title: "Intermediate",
    description: "Vocabulary for work, school, and leisure",
    duration: 6,
  },
  B2: {
    title: "Upper-Intermediate",
    description: "Complex vocabulary for abstract topics",
    duration: 7,
  },
  C1: {
    title: "Advanced",
    description: "Sophisticated vocabulary for professional use",
    duration: 8,
  },
};

export function getRandomLevel(): DelLevel {
  return QUIZ_LEVELS[Math.floor(Math.random() * QUIZ_LEVELS.length)];
}

export function shuffleArray<T>(array: T[]): T[] {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function calculateAccuracy(correct: number, total: number): number {
  return Math.round((correct / total) * 100);
}

export function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}
