import { VocabularyItem, VocabularyStats, DelLevel } from "@shared/schema";

const STORAGE_KEY = "french_vocabulary_tracker";

export class VocabularyTracker {
  private vocabulary: Map<string, VocabularyItem> = new Map();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const data = JSON.parse(stored);
        this.vocabulary = new Map(Object.entries(data));
      }
    } catch (error) {
      console.error("Failed to load vocabulary from storage:", error);
    }
  }

  private saveToStorage() {
    try {
      const data = Object.fromEntries(this.vocabulary);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error("Failed to save vocabulary to storage:", error);
    }
  }

  addWord(word: string, meaning: string, level: DelLevel) {
    const now = Date.now();
    const existing = this.vocabulary.get(word);

    if (!existing) {
      const item: VocabularyItem = {
        word,
        meaning,
        level,
        status: "just_learned",
        correctAnswers: 0,
        incorrectAnswers: 0,
        firstSeenAt: now,
        lastSeenAt: now,
      };
      this.vocabulary.set(word, item);
      this.saveToStorage();
    }
  }

  updateWordStatus(word: string, isCorrect: boolean) {
    const item = this.vocabulary.get(word);
    if (!item) return;

    const now = Date.now();
    item.lastSeenAt = now;
    item.lastAnsweredAt = now;

    if (isCorrect) {
      item.correctAnswers++;
      
      // Progress from just_learned -> very_learned
      if (item.status === "just_learned" && item.correctAnswers >= 3) {
        item.status = "very_learned";
      }
    } else {
      item.incorrectAnswers++;
      
      // If they get it wrong and it was very_learned, move back to just_learned
      if (item.status === "very_learned") {
        item.status = "just_learned";
      }
    }

    this.vocabulary.set(word, item);
    this.saveToStorage();
  }

  getWordsByStatus(status: VocabularyItem["status"], level?: DelLevel): VocabularyItem[] {
    return Array.from(this.vocabulary.values()).filter(item => {
      const statusMatch = item.status === status;
      const levelMatch = !level || item.level === level;
      return statusMatch && levelMatch;
    });
  }

  getVocabularyStats(): VocabularyStats {
    const stats: VocabularyStats = {
      justLearned: 0,
      veryLearned: 0,
      totalWords: 0,
      byLevel: {},
    };

    const levels: DelLevel[] = ["A1", "A2", "B1", "B2", "C1"];
    levels.forEach(level => {
      stats.byLevel[level] = {
        justLearned: 0,
        veryLearned: 0,
      };
    });

    Array.from(this.vocabulary.values()).forEach(item => {
      stats.totalWords++;
      
      switch (item.status) {
        case "just_learned":
          stats.justLearned++;
          stats.byLevel[item.level].justLearned++;
          break;
        case "very_learned":
          stats.veryLearned++;
          stats.byLevel[item.level].veryLearned++;
          break;
      }
    });

    return stats;
  }

  getWordsForReview(level: DelLevel, count: number = 5): VocabularyItem[] {
    // Get distribution for spaced repetition
    const justLearned = this.getWordsByStatus("just_learned", level);
    
    // Focus on just learned words for review (prioritize by last seen time)
    const sortedJustLearned = justLearned.sort((a, b) => a.lastSeenAt - b.lastSeenAt);
    return sortedJustLearned.slice(0, count);
  }

  exportData(): string {
    return JSON.stringify(Object.fromEntries(this.vocabulary), null, 2);
  }

  importData(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData);
      this.vocabulary = new Map(Object.entries(data));
      this.saveToStorage();
      return true;
    } catch (error) {
      console.error("Failed to import vocabulary data:", error);
      return false;
    }
  }

  clearAllData() {
    this.vocabulary.clear();
    localStorage.removeItem(STORAGE_KEY);
  }
}

export const vocabularyTracker = new VocabularyTracker();