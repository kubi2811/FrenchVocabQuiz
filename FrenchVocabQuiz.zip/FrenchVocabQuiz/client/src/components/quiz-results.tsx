import { QuizResult } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trophy, RotateCcw, TrendingUp, Check, X } from "lucide-react";

interface QuizResultsProps {
  result: QuizResult;
  onRetakeQuiz: () => void;
  onSelectNewLevel: () => void;
}

export default function QuizResults({ result, onRetakeQuiz, onSelectNewLevel }: QuizResultsProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getAccuracyPercentage = () => {
    return Math.round((result.score / result.totalQuestions) * 100);
  };

  const getScoreColor = () => {
    const percentage = getAccuracyPercentage();
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="space-y-6">
      {/* Score Overview */}
      <Card>
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trophy className="text-green-600 w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Quiz Complete!</h2>
            <p className="text-gray-600">You've finished the DELF {result.level} vocabulary quiz</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center">
              <div className={`text-3xl font-bold mb-1 ${getScoreColor()}`}>
                {result.score}
              </div>
              <div className="text-sm text-gray-600">Correct Answers</div>
            </div>
            <div className="text-center">
              <div className={`text-3xl font-bold mb-1 ${getScoreColor()}`}>
                {getAccuracyPercentage()}%
              </div>
              <div className="text-sm text-gray-600">Accuracy</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {formatTime(result.timeTaken)}
              </div>
              <div className="text-sm text-gray-600">Time Taken</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={onRetakeQuiz} className="bg-primary hover:bg-primary/90">
              <RotateCcw className="w-4 h-4 mr-2" />
              Retake Quiz
            </Button>
            <Button variant="outline" onClick={onSelectNewLevel}>
              <TrendingUp className="w-4 h-4 mr-2" />
              Try Different Level
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Results */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Question Review</h3>
          <div className="space-y-4">
            {result.answers.map((answer, index) => (
              <div
                key={index}
                className={`border rounded-lg p-4 ${
                  answer.isCorrect 
                    ? "bg-green-50 border-green-200" 
                    : "bg-red-50 border-red-200"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900">
                    Question {index + 1}
                  </span>
                  <div className="flex items-center space-x-2">
                    {answer.isCorrect ? (
                      <>
                        <Check className="w-4 h-4 text-green-600" />
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Correct
                        </Badge>
                      </>
                    ) : (
                      <>
                        <X className="w-4 h-4 text-red-600" />
                        <Badge variant="destructive">Incorrect</Badge>
                      </>
                    )}
                  </div>
                </div>
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Word:</strong> {answer.word}
                </p>
                <p className="text-sm text-gray-600 mb-1">
                  <strong>Your answer:</strong> {answer.userAnswer} {answer.isCorrect ? "✓" : "✗"}
                </p>
                {!answer.isCorrect && (
                  <p className="text-sm text-gray-600">
                    <strong>Correct answer:</strong> {answer.correctAnswer}
                  </p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
