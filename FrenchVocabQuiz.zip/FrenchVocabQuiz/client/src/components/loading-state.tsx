import { Loader2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function LoadingState() {
  return (
    <div className="min-h-screen quiz-gradient flex items-center justify-center">
      <Card className="max-w-md mx-4">
        <CardContent className="p-8 text-center">
          <div className="flex items-center justify-center mb-4">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Generating Questions...</h3>
          <p className="text-gray-600">Please wait while we prepare your DELF vocabulary quiz.</p>
        </CardContent>
      </Card>
    </div>
  );
}
