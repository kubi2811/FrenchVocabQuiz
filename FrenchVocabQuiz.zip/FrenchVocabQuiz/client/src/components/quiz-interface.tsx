import { QuizQuestion } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ChevronLeft, ChevronRight, Clock } from "lucide-react";

// Utility function to clean HTML tags
const cleanHtml = (text: string): string => {
  if (!text) return text;
  return text.replace(/<[^>]*>/g, '');
};

interface QuizInterfaceProps {
  question: QuizQuestion;
  currentQuestionIndex: number;
  totalQuestions: number;
  selectedAnswer: string | null;
  showFeedback: boolean;
  score: number;
  timeRemaining: number;
  onSelectAnswer: (answer: string) => void;
  onNextQuestion: () => void;
  onPreviousQuestion: () => void;
  canGoNext: boolean;
  canGoPrev: boolean;
}

export default function QuizInterface({
  question,
  currentQuestionIndex,
  totalQuestions,
  selectedAnswer,
  showFeedback,
  score,
  timeRemaining,
  onSelectAnswer,
  onNextQuestion,
  onPreviousQuestion,
  canGoNext,
  canGoPrev,
}: QuizInterfaceProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getProgressPercentage = () => {
    return ((currentQuestionIndex + 1) / totalQuestions) * 100;
  };

  const getAnswerOptionClasses = (option: string) => {
    let classes = "w-full p-4 text-left rounded-lg border-2 transition-all duration-200 ";
    
    if (showFeedback) {
      if (option === question.answer) {
        classes += "bg-green-50 border-green-500 text-green-800";
      } else if (option === selectedAnswer && option !== question.answer) {
        classes += "bg-red-50 border-red-500 text-red-800";
      } else {
        classes += "bg-gray-50 border-gray-300 text-gray-600";
      }
    } else {
      if (option === selectedAnswer) {
        classes += "bg-primary bg-opacity-10 border-primary text-primary";
      } else {
        classes += "bg-gray-50 hover:bg-gray-100 border-transparent hover:border-primary text-gray-900";
      }
    }
    
    return classes;
  };

  return (
    <div className="space-y-6">
      {/* Quiz Progress */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold text-gray-900">DELF {question.level} Quiz</h2>
              <p className="text-sm text-gray-600">
                Question {currentQuestionIndex + 1} of {totalQuestions}
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Score</div>
              <div className="text-lg font-semibold text-primary">
                {score}/{totalQuestions}
              </div>
            </div>
          </div>
          <Progress value={getProgressPercentage()} className="w-full" />
        </CardContent>
      </Card>

      {/* Question */}
      <Card>
        <CardContent className="p-8">
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-4">
              <Badge variant="secondary">Vocabulary</Badge>
              <Badge variant="outline">{question.level}</Badge>
            </div>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg border-l-4 border-primary">
                <p className="text-lg font-medium text-gray-900 mb-2">
                  "{cleanHtml(question.sentence)}"
                </p>
                <p className="text-sm text-gray-600">Context sentence in French</p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">
                  {cleanHtml(question.question)}
                </h3>
              </div>
            </div>
          </div>

          {/* Answer Options */}
          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => onSelectAnswer(option)}
                className={getAnswerOptionClasses(option)}
                disabled={showFeedback}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                    showFeedback && option === question.answer
                      ? "bg-green-500 border-green-500 text-white"
                      : showFeedback && option === selectedAnswer && option !== question.answer
                      ? "bg-red-500 border-red-500 text-white"
                      : option === selectedAnswer
                      ? "bg-primary border-primary text-white"
                      : "bg-white border-gray-300 text-gray-600"
                  }`}>
                    <span className="text-sm font-medium">
                      {String.fromCharCode(65 + index)}
                    </span>
                  </div>
                  <span className="font-medium">{cleanHtml(option)}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Feedback */}
          {showFeedback && (
            <div className="mt-6 p-4 rounded-lg bg-green-50 border-l-4 border-green-500">
              <div className="flex items-start space-x-3">
                <div className="flex-1">
                  <h4 className="font-semibold text-green-800 mb-1">
                    {selectedAnswer === question.answer ? "Correct!" : "Incorrect"}
                  </h4>
                  <p className="text-green-700 text-sm">
                    The correct answer is "<strong>{question.answer}</strong>".
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
            <Button
              variant="ghost"
              onClick={onPreviousQuestion}
              disabled={!canGoPrev}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>
            <div className="text-sm text-gray-500">
              <Clock className="w-4 h-4 inline mr-1" />
              {formatTime(timeRemaining)}
            </div>
            <Button
              onClick={onNextQuestion}
              disabled={!canGoNext}
              className="bg-primary hover:bg-primary/90"
            >
              {currentQuestionIndex === totalQuestions - 1 ? "Finish" : "Next"}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
