import { DelLevel } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Sprout, Leaf, Mountain, Rocket, Crown } from "lucide-react";

interface LevelSelectionProps {
  onSelectLevel: (level: DelLevel) => void;
}

const levelData = [
  {
    level: "A1" as DelLevel,
    title: "Beginner",
    description: "Basic vocabulary for everyday situations. Perfect for beginners starting their French journey.",
    icon: Sprout,
    color: "blue",
    duration: "~5 minutes",
  },
  {
    level: "A2" as DelLevel,
    title: "Elementary",
    description: "Expanded vocabulary for common topics like family, shopping, and local geography.",
    icon: Leaf,
    color: "green",
    duration: "~5 minutes",
  },
  {
    level: "B1" as DelLevel,
    title: "Intermediate",
    description: "Vocabulary for work, school, and leisure activities. Handle most travel situations.",
    icon: Mountain,
    color: "yellow",
    duration: "~6 minutes",
  },
  {
    level: "B2" as DelLevel,
    title: "Upper-Intermediate",
    description: "Complex vocabulary for abstract topics and professional contexts.",
    icon: Rocket,
    color: "orange",
    duration: "~7 minutes",
  },
  {
    level: "C1" as DelLevel,
    title: "Advanced",
    description: "Sophisticated vocabulary for academic and professional excellence.",
    icon: Crown,
    color: "purple",
    duration: "~8 minutes",
  },
];

export default function LevelSelection({ onSelectLevel }: LevelSelectionProps) {
  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-100 text-blue-600",
      green: "bg-green-100 text-green-600",
      yellow: "bg-yellow-100 text-yellow-600",
      orange: "bg-orange-100 text-orange-600",
      purple: "bg-purple-100 text-purple-600",
    };
    return colorMap[color as keyof typeof colorMap] || "bg-gray-100 text-gray-600";
  };

  const getIconColorClasses = (color: string) => {
    const colorMap = {
      blue: "text-blue-500",
      green: "text-green-500",
      yellow: "text-yellow-500",
      orange: "text-orange-500",
      purple: "text-purple-500",
    };
    return colorMap[color as keyof typeof colorMap] || "text-gray-500";
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-3">Choose Your DELF Level</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Select your proficiency level to start practicing French vocabulary with questions tailored to your DELF exam preparation needs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {levelData.map((item) => {
          const Icon = item.icon;
          return (
            <Card 
              key={item.level}
              className="cursor-pointer hover:shadow-lg transition-shadow duration-300 border-2 border-transparent hover:border-primary"
              onClick={() => onSelectLevel(item.level)}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(item.color)}`}>
                    <span className="font-bold text-lg">{item.level}</span>
                  </div>
                  <div className={getIconColorClasses(item.color)}>
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>{item.duration}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
