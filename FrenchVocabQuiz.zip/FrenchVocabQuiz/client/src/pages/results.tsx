import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Trophy, RotateCcw, TrendingUp, Clock, Check, X, Home, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QuizResult } from "@shared/schema";

export default function Results() {
  const [, setLocation] = useLocation();
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

  useEffect(() => {
    const storedResult = localStorage.getItem("quizResult");
    if (storedResult) {
      setQuizResult(JSON.parse(storedResult));
    } else {
      // No quiz result found, redirect to home
      setLocation("/");
    }
  }, [setLocation]);

  if (!quizResult) {
    return null;
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getAccuracyPercentage = () => {
    return Math.round((quizResult.score / quizResult.totalQuestions) * 100);
  };

  const getScoreColor = () => {
    const percentage = getAccuracyPercentage();
    if (percentage >= 80) return "text-green-600";
    if (percentage >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const retakeQuiz = () => {
    localStorage.removeItem("quizResult");
    setLocation(`/quiz/${quizResult.level}`);
  };

  const selectNewLevel = () => {
    localStorage.removeItem("quizResult");
    setLocation("/");
  };

  return (
    <div className="min-h-screen quiz-gradient">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Quiz Results</h1>
                <p className="text-sm text-gray-600">DELF {quizResult.level} Vocabulary Quiz</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Score Overview */}
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mb-6">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Trophy className="text-green-600 w-8 h-8" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Quiz Complete!</h2>
                <p className="text-gray-600">You've finished the DELF {quizResult.level} vocabulary quiz</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className={`text-3xl font-bold mb-1 ${getScoreColor()}`}>
                    {quizResult.score}
                  </div>
                  <div className="text-sm text-gray-600">Correct Answers</div>
                </div>
                <div className="text-center">
                  <div className={`text-3xl font-bold mb-1 ${getScoreColor()}`}>
                    {getAccuracyPercentage()}%
                  </div>
                  <div className="text-sm text-gray-600">Accuracy</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">
                    {formatTime(quizResult.timeTaken)}
                  </div>
                  <div className="text-sm text-gray-600">Time Taken</div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={retakeQuiz} className="bg-primary hover:bg-primary/90">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Retake Quiz
                </Button>
                <Button variant="outline" onClick={selectNewLevel}>
                  <BookOpen className="w-4 h-4 mr-2" />
                  Try Different Level
                </Button>
                <Button
                  onClick={() => setLocation("/progress")}
                  variant="outline"
                  className="border-green-500 text-green-600 hover:bg-green-50"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Progress
                </Button>
                <Button
                  onClick={() => setLocation("/")}
                  variant="outline"
                  className="border-gray-400 text-gray-600 hover:bg-gray-50"
                >
                  <Home className="w-4 h-4 mr-2" />
                  Back to Home
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Detailed Results */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Question Review</h3>
              <div className="space-y-4">
                {quizResult.answers.map((result, index) => (
                  <div
                    key={index}
                    className={`border rounded-lg p-4 ${
                      result.isCorrect 
                        ? "bg-green-50 border-green-200" 
                        : "bg-red-50 border-red-200"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-900">
                        Question {index + 1}
                      </span>
                      <div className="flex items-center space-x-2">
                        {result.isCorrect ? (
                          <>
                            <Check className="w-4 h-4 text-green-600" />
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              Correct
                            </Badge>
                          </>
                        ) : (
                          <>
                            <X className="w-4 h-4 text-red-600" />
                            <Badge variant="destructive">Incorrect</Badge>
                          </>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-gray-700 mb-2">
                      <strong>Word:</strong> {result.word}
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Your answer:</strong> {result.userAnswer} {result.isCorrect ? "✓" : "✗"}
                    </p>
                    {!result.isCorrect && (
                      <p className="text-sm text-gray-600">
                        <strong>Correct answer:</strong> {result.correctAnswer}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Performance Tips */}
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Tips</h3>
              <div className="space-y-3">
                {getAccuracyPercentage() >= 80 ? (
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                      <Check className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Excellent Performance!</p>
                      <p className="text-sm text-gray-600">
                        You have a strong grasp of {quizResult.level} vocabulary. Consider trying the next level to challenge yourself further.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Keep Practicing!</p>
                      <p className="text-sm text-gray-600">
                        Focus on contextual reading and try to understand how words are used in different situations. 
                        Regular practice will help improve your vocabulary retention.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
