import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { GraduationCap, User, Sprout, Leaf, Mountain, Rocket, Crown, Dice6, Clock, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { DelLevel } from "@shared/schema";
import { vocabularyTracker } from "@/lib/vocabulary-tracker";

const levelData = [
  {
    level: "A1" as DelLevel,
    title: "Beginner",
    description: "Basic vocabulary for everyday situations. Perfect for beginners starting their French journey.",
    icon: Sprout,
    color: "blue",
    duration: "~5 minutes",
  },
  {
    level: "A2" as DelLevel,
    title: "Elementary",
    description: "Expanded vocabulary for common topics like family, shopping, and local geography.",
    icon: Leaf,
    color: "green",
    duration: "~5 minutes",
  },
  {
    level: "B1" as DelLevel,
    title: "Intermediate",
    description: "Vocabulary for work, school, and leisure activities. Handle most travel situations.",
    icon: Mountain,
    color: "yellow",
    duration: "~6 minutes",
  },
  {
    level: "B2" as DelLevel,
    title: "Upper-Intermediate",
    description: "Complex vocabulary for abstract topics and professional contexts.",
    icon: Rocket,
    color: "orange",
    duration: "~7 minutes",
  },
  {
    level: "C1" as DelLevel,
    title: "Advanced",
    description: "Sophisticated vocabulary for academic and professional excellence.",
    icon: Crown,
    color: "purple",
    duration: "~8 minutes",
  },
];

export default function Home() {
  const [, setLocation] = useLocation();
  const [vocabularyStats, setVocabularyStats] = useState({ totalWords: 0, veryLearned: 0 });

  useEffect(() => {
    const stats = vocabularyTracker.getVocabularyStats();
    setVocabularyStats(stats);
  }, []);

  const { data: randomLevel } = useQuery({
    queryKey: ["/api/quiz/random-level"],
    enabled: false,
  });

  const selectLevel = (level: DelLevel) => {
    setLocation(`/quiz/${level}`);
  };

  const handleRandomLevel = async () => {
    try {
      const response = await fetch("/api/quiz/random-level");
      const data = await response.json();
      setLocation(`/quiz/${data.level}`);
    } catch (error) {
      console.error("Error getting random level:", error);
    }
  };

  const getColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-100 text-blue-600",
      green: "bg-green-100 text-green-600",
      yellow: "bg-yellow-100 text-yellow-600",
      orange: "bg-orange-100 text-orange-600",
      purple: "bg-purple-100 text-purple-600",
    };
    return colorMap[color as keyof typeof colorMap] || "bg-gray-100 text-gray-600";
  };

  const getIconColorClasses = (color: string) => {
    const colorMap = {
      blue: "text-blue-500",
      green: "text-green-500",
      yellow: "text-yellow-500",
      orange: "text-orange-500",
      purple: "text-purple-500",
    };
    return colorMap[color as keyof typeof colorMap] || "text-gray-500";
  };

  return (
    <div className="min-h-screen quiz-gradient">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">French Vocabulary Quiz</h1>
                <p className="text-sm text-gray-600">DELF Exam Preparation</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation("/progress")}
                className="flex items-center space-x-2"
              >
                <TrendingUp className="w-4 h-4" />
                <span>Progress</span>
              </Button>
              <div className="text-right">
                <div className="text-sm text-gray-500">Words Learned</div>
                <div className="text-lg font-semibold text-primary">{vocabularyStats.veryLearned}</div>
              </div>
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="text-gray-600 text-sm" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Choose Your DELF Level</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Select your proficiency level to start practicing French vocabulary with questions tailored to your DELF exam preparation needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {levelData.map((item) => {
              const Icon = item.icon;
              return (
                <Card 
                  key={item.level}
                  className="cursor-pointer hover:shadow-lg transition-shadow duration-300 border-2 border-transparent hover:border-primary"
                  onClick={() => selectLevel(item.level)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getColorClasses(item.color)}`}>
                        <span className="font-bold text-lg">{item.level}</span>
                      </div>
                      <div className={getIconColorClasses(item.color)}>
                        <Icon className="w-6 h-6" />
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="w-4 h-4 mr-2" />
                      <span>{item.duration}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            <Card 
              className="cursor-pointer hover:shadow-lg transition-shadow duration-300 bg-gradient-to-br from-primary to-indigo-600 text-white border-2 border-transparent hover:border-primary"
              onClick={handleRandomLevel}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                    <Dice6 className="text-white w-5 h-5" />
                  </div>
                  <div className="text-white">
                    <Dice6 className="w-6 h-6" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-2">Random Level</h3>
                <p className="text-indigo-100 text-sm mb-4">
                  Challenge yourself with vocabulary from any DELF level. Perfect for mixed practice!
                </p>
                <div className="flex items-center text-sm text-indigo-200">
                  <Clock className="w-4 h-4 mr-2" />
                  <span>~5-8 minutes</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <div className="flex items-center space-x-2">
                <GraduationCap className="text-primary w-4 h-4" />
                <span className="text-sm text-gray-600">Powered by DELF Standards</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                About
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                Help
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-primary">
                Contact
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
