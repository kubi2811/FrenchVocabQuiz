import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ArrowLeft, ChevronLeft, ChevronRight, Clock, Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { QuizQuestion, DelLevel } from "@shared/schema";
import LoadingState from "@/components/loading-state";
import { vocabularyTracker } from "@/lib/vocabulary-tracker";

interface QuizState {
  currentQuestionIndex: number;
  answers: { questionIndex: number; answer: string; isCorrect: boolean }[];
  score: number;
  timeRemaining: number;
  selectedAnswer: string | null;
  showFeedback: boolean;
  quizStartTime: number;
  useAI: boolean;
}

export default function Quiz() {
  const [match, params] = useRoute("/quiz/:level");
  const [, setLocation] = useLocation();
  const level = params?.level as DelLevel;

  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestionIndex: 0,
    answers: [],
    score: 0,
    timeRemaining: 300, // 5 minutes
    selectedAnswer: null,
    showFeedback: false,
    quizStartTime: Date.now(),
    useAI: true, // Default to AI mode
  });

  const { data: questionsData, isLoading } = useQuery({
    queryKey: ["/api/quiz/generate", level, quizState.useAI],
    queryFn: async () => {
      // Get review words for spaced repetition
      const reviewWords = vocabularyTracker.getWordsForReview(level, 3);
      
      const response = await apiRequest("POST", "/api/quiz/generate", { 
        level,
        useAI: quizState.useAI,
        reviewWords: reviewWords.length > 0 ? reviewWords : undefined
      });
      return response.json();
    },
    enabled: !!level,
  });

  const questions: QuizQuestion[] = questionsData?.questions || [];
  const currentQuestion = questions[quizState.currentQuestionIndex];

  // Timer effect
  useEffect(() => {
    if (questions.length === 0) return;

    const timer = setInterval(() => {
      setQuizState(prev => {
        if (prev.timeRemaining <= 0) {
          clearInterval(timer);
          finishQuiz();
          return prev;
        }
        return { ...prev, timeRemaining: prev.timeRemaining - 1 };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [questions.length]);

  const selectAnswer = (answer: string) => {
    if (quizState.showFeedback) return;

    const isCorrect = answer === currentQuestion.answer;
    setQuizState(prev => ({
      ...prev,
      selectedAnswer: answer,
      showFeedback: true,
      score: isCorrect ? prev.score + 1 : prev.score,
    }));

    // Update vocabulary tracker
    vocabularyTracker.addWord(currentQuestion.word, currentQuestion.answer, level);
    vocabularyTracker.updateWordStatus(currentQuestion.word, isCorrect);

    // Record the answer
    const newAnswer = {
      questionIndex: quizState.currentQuestionIndex,
      answer,
      isCorrect,
    };

    setQuizState(prev => ({
      ...prev,
      answers: [...prev.answers, newAnswer],
    }));
  };

  const nextQuestion = () => {
    if (quizState.currentQuestionIndex < questions.length - 1) {
      setQuizState(prev => ({
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1,
        selectedAnswer: null,
        showFeedback: false,
      }));
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    const timeTaken = Math.floor((Date.now() - quizState.quizStartTime) / 1000);
    const quizResult = {
      level,
      score: quizState.score,
      totalQuestions: questions.length,
      answers: quizState.answers.map((answer, index) => ({
        questionIndex: answer.questionIndex,
        userAnswer: answer.answer,
        correctAnswer: questions[answer.questionIndex].answer,
        isCorrect: answer.isCorrect,
        word: questions[answer.questionIndex].word,
      })),
      timeTaken,
    };

    // Store result in localStorage for the results page
    localStorage.setItem("quizResult", JSON.stringify(quizResult));
    setLocation("/results");
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const getProgressPercentage = () => {
    return ((quizState.currentQuestionIndex + 1) / questions.length) * 100;
  };

  const getAnswerOptionClasses = (option: string) => {
    let classes = "w-full p-4 text-left rounded-lg border-2 transition-all duration-200 ";
    
    if (quizState.showFeedback) {
      if (option === currentQuestion.answer) {
        classes += "bg-green-50 border-green-500 text-green-800";
      } else if (option === quizState.selectedAnswer && option !== currentQuestion.answer) {
        classes += "bg-red-50 border-red-500 text-red-800";
      } else {
        classes += "bg-gray-50 border-gray-300 text-gray-600";
      }
    } else {
      if (option === quizState.selectedAnswer) {
        classes += "bg-primary bg-opacity-10 border-primary text-primary";
      } else {
        classes += "bg-gray-50 hover:bg-gray-100 border-transparent hover:border-primary text-gray-900";
      }
    }
    
    return classes;
  };

  if (!match) {
    return null;
  }

  if (isLoading) {
    return <LoadingState />;
  }

  if (!questions.length) {
    return (
      <div className="min-h-screen quiz-gradient flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="p-8 text-center">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">No Questions Available</h2>
            <p className="text-gray-600 mb-4">Unable to generate questions for this level.</p>
            <Button onClick={() => setLocation("/")}>Return Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen quiz-gradient">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation("/")}
                className="w-10 h-10 p-0"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">French Vocabulary Quiz</h1>
                <p className="text-sm text-gray-600">DELF Exam Preparation</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Time Remaining</div>
              <div className="text-lg font-semibold text-primary">{formatTime(quizState.timeRemaining)}</div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Quiz Progress */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h2 className="text-lg font-semibold text-gray-900">DELF {level} Quiz</h2>
                      {quizState.useAI && (
                        <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                          <Brain className="w-3 h-3 mr-1" />
                          AI-Powered
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">
                      Question {quizState.currentQuestionIndex + 1} of {questions.length}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuizState(prev => ({ ...prev, useAI: !prev.useAI }));
                      // This will trigger a re-fetch with the new mode
                      window.location.reload();
                    }}
                    disabled={isLoading}
                  >
                    {quizState.useAI ? "Switch to Static" : "Switch to AI"}
                  </Button>
                  <div className="text-right">
                    <div className="text-sm text-gray-500">Score</div>
                    <div className="text-lg font-semibold text-primary">
                      {quizState.score}/{questions.length}
                    </div>
                  </div>
                </div>
              </div>
              <Progress value={getProgressPercentage()} className="w-full" />
            </CardContent>
          </Card>

          {/* Question */}
          <Card>
            <CardContent className="p-8">
              <div className="mb-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Badge variant="secondary">Vocabulary</Badge>
                  <Badge variant="outline">{level}</Badge>
                </div>
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-lg border-l-4 border-primary">
                    <p className="text-lg font-medium text-gray-900 mb-2">
                      "{currentQuestion.sentence.replace(currentQuestion.word, 
                        `<strong class="text-primary">${currentQuestion.word}</strong>`
                      )}"
                    </p>
                    <p className="text-sm text-gray-600">Context sentence in French</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {currentQuestion.question}
                    </h3>
                  </div>
                </div>
              </div>

              {/* Answer Options */}
              <div className="space-y-3">
                {currentQuestion.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => selectAnswer(option)}
                    className={getAnswerOptionClasses(option)}
                    disabled={quizState.showFeedback}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                        quizState.showFeedback && option === currentQuestion.answer
                          ? "bg-green-500 border-green-500 text-white"
                          : quizState.showFeedback && option === quizState.selectedAnswer && option !== currentQuestion.answer
                          ? "bg-red-500 border-red-500 text-white"
                          : option === quizState.selectedAnswer
                          ? "bg-primary border-primary text-white"
                          : "bg-white border-gray-300 text-gray-600"
                      }`}>
                        <span className="text-sm font-medium">
                          {String.fromCharCode(65 + index)}
                        </span>
                      </div>
                      <span className="font-medium">{option}</span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Feedback */}
              {quizState.showFeedback && (
                <div className="mt-6 p-4 rounded-lg bg-green-50 border-l-4 border-green-500">
                  <div className="flex items-start space-x-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-green-800 mb-1">
                        {quizState.selectedAnswer === currentQuestion.answer ? "Correct!" : "Incorrect"}
                      </h4>
                      <p className="text-green-700 text-sm">
                        The correct answer is "<strong>{currentQuestion.answer}</strong>".
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation */}
              <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-200">
                <Button
                  variant="ghost"
                  onClick={() => setQuizState(prev => ({ ...prev, currentQuestionIndex: Math.max(0, prev.currentQuestionIndex - 1) }))}
                  disabled={quizState.currentQuestionIndex === 0}
                >
                  <ChevronLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
                <div className="text-sm text-gray-500">
                  <Clock className="w-4 h-4 inline mr-1" />
                  {formatTime(quizState.timeRemaining)}
                </div>
                <Button
                  onClick={nextQuestion}
                  disabled={!quizState.showFeedback}
                  className="bg-primary hover:bg-primary/90"
                >
                  {quizState.currentQuestionIndex === questions.length - 1 ? "Finish" : "Next"}
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
