import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft, BookOpen, Brain, Trophy, Download, Upload, Trash2, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VocabularyStats, DelLevel } from "@shared/schema";
import { vocabularyTracker } from "@/lib/vocabulary-tracker";
import { useToast } from "@/hooks/use-toast";

export default function ProgressPage() {
  const [, setLocation] = useLocation();
  const [stats, setStats] = useState<VocabularyStats | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<DelLevel>("A1");
  const { toast } = useToast();

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = () => {
    const currentStats = vocabularyTracker.getVocabularyStats();
    setStats(currentStats);
  };

  const handleExportData = () => {
    try {
      const data = vocabularyTracker.exportData();
      const blob = new Blob([data], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `french-vocabulary-progress-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Data Exported",
        description: "Your vocabulary progress has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export vocabulary data.",
        variant: "destructive",
      });
    }
  };

  const handleImportData = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const data = e.target?.result as string;
            if (vocabularyTracker.importData(data)) {
              loadStats();
              toast({
                title: "Data Imported",
                description: "Your vocabulary progress has been imported successfully.",
              });
            } else {
              throw new Error("Invalid file format");
            }
          } catch (error) {
            toast({
              title: "Import Failed",
              description: "Failed to import vocabulary data. Please check the file format.",
              variant: "destructive",
            });
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const handleClearData = () => {
    if (confirm("Are you sure you want to clear all vocabulary progress? This action cannot be undone.")) {
      vocabularyTracker.clearAllData();
      loadStats();
      toast({
        title: "Data Cleared",
        description: "All vocabulary progress has been cleared.",
      });
    }
  };

  if (!stats) {
    return (
      <div className="min-h-screen quiz-gradient flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="w-12 h-12 text-primary mx-auto mb-4" />
          <p className="text-gray-600">Loading your progress...</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "just_learned":
        return "bg-yellow-100 text-yellow-800";
      case "very_learned":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "just_learned":
        return <Brain className="w-4 h-4" />;
      case "very_learned":
        return <Trophy className="w-4 h-4" />;
      default:
        return <BookOpen className="w-4 h-4" />;
    }
  };

  const getProgressPercentage = (learned: number, total: number) => {
    return total > 0 ? Math.round((learned / total) * 100) : 0;
  };

  const levels: DelLevel[] = ["A1", "A2", "B1", "B2", "C1"];

  return (
    <div className="min-h-screen quiz-gradient">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation("/")}
                className="w-10 h-10 p-0"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Vocabulary Progress</h1>
                <p className="text-sm text-gray-600">Track your French learning journey</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleExportData}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={handleImportData}>
                <Upload className="w-4 h-4 mr-2" />
                Import
              </Button>
              <Button variant="outline" size="sm" onClick={handleClearData} className="text-red-600 hover:text-red-700">
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-900">{stats.totalWords}</div>
                    <div className="text-sm text-gray-600">Total Words</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Brain className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-900">{stats.justLearned}</div>
                    <div className="text-sm text-gray-600">Just Learned</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-900">{stats.veryLearned}</div>
                    <div className="text-sm text-gray-600">Very Learned</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress by Level */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="w-5 h-5" />
                <span>Progress by DELF Level</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {levels.map((level) => {
                  const levelStats = stats.byLevel[level];
                  const total = levelStats.notLearned + levelStats.justLearned + levelStats.veryLearned;
                  const learned = levelStats.justLearned + levelStats.veryLearned;
                  const percentage = getProgressPercentage(learned, total);

                  return (
                    <div key={level} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Badge variant="outline" className="font-semibold">
                            {level}
                          </Badge>
                          <span className="text-sm font-medium text-gray-900">
                            {learned}/{total} words learned
                          </span>
                        </div>
                        <span className="text-sm font-semibold text-primary">
                          {percentage}%
                        </span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                            <span>{levelStats.justLearned} just learned</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span>{levelStats.veryLearned} very learned</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Word Details by Level */}
          <Card>
            <CardHeader>
              <CardTitle>Vocabulary Details</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs value={selectedLevel} onValueChange={(value) => setSelectedLevel(value as DelLevel)}>
                <TabsList className="grid w-full grid-cols-5">
                  {levels.map((level) => (
                    <TabsTrigger key={level} value={level}>
                      {level}
                    </TabsTrigger>
                  ))}
                </TabsList>
                
                {levels.map((level) => (
                  <TabsContent key={level} value={level} className="mt-6">
                    <div className="space-y-4">
                      {["just_learned", "very_learned"].map((status) => {
                        const words = vocabularyTracker.getWordsByStatus(status as any, level);
                        
                        return (
                          <div key={status}>
                            <div className="flex items-center space-x-2 mb-3">
                              <Badge className={getStatusColor(status)}>
                                {getStatusIcon(status)}
                                <span className="ml-1 capitalize">
                                  {status.replace("_", " ")} ({words.length})
                                </span>
                              </Badge>
                            </div>
                            
                            {words.length > 0 ? (
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                                {words.slice(0, 12).map((word) => (
                                  <div
                                    key={word.word}
                                    className="p-3 bg-gray-50 rounded-lg border"
                                  >
                                    <div className="font-medium text-gray-900">{word.word}</div>
                                    <div className="text-sm text-gray-600">{word.meaning}</div>
                                    <div className="text-xs text-gray-500 mt-1">
                                      ✓ {word.correctAnswers} | ✗ {word.incorrectAnswers}
                                    </div>
                                  </div>
                                ))}
                                {words.length > 12 && (
                                  <div className="p-3 bg-gray-50 rounded-lg border flex items-center justify-center">
                                    <span className="text-sm text-gray-500">
                                      +{words.length - 12} more words
                                    </span>
                                  </div>
                                )}
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500 italic">
                                No words in this category yet.
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}