# French DELF Vocabulary Quiz Application

## Overview

This is a full-stack French DELF (Diplôme d'Études en Langue Française) vocabulary quiz application built with React, Express.js, and TypeScript. The application allows users to test their French vocabulary skills across different DELF proficiency levels (A1, A2, B1, B2, C1) through interactive quizzes with AI-powered question generation and intelligent vocabulary tracking.

## Key Features

### Vocabulary Tracking System
- **Three Learning States**: Words are categorized as "not learned", "just learned", or "very learned" based on user performance
- **Spaced Repetition**: Intelligent algorithm prioritizes review of "just learned" words alongside new vocabulary
- **Progress Analytics**: Detailed statistics and progress tracking by DELF level
- **Data Persistence**: All progress saved to local storage with import/export functionality

### AI-Powered Question Generation
- **Gemini Integration**: Uses Google's Gemini API for dynamic question generation
- **Personalized Content**: Questions adapt based on user's vocabulary progress and review needs
- **Fallback Support**: Static question bank available when AI is disabled
- **Context-Aware**: French sentences provide meaningful context for vocabulary learning

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: React hooks with TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: PostgreSQL sessions with connect-pg-simple
- **API Design**: RESTful API with JSON responses

### Development Setup
- **Monorepo Structure**: Client and server code in same repository
- **Shared Types**: Common TypeScript types and schemas in shared directory
- **Hot Reloading**: Vite dev server with Express API proxy

## Key Components

### Frontend Components
- **Level Selection**: Interactive cards for choosing DELF levels
- **Quiz Interface**: Real-time quiz with timer and progress tracking
- **Results Display**: Detailed performance analytics and review
- **Loading States**: User-friendly loading indicators
- **Responsive Design**: Mobile-first approach with shadcn/ui components

### Backend Services
- **Quiz Generation**: Dynamic question generation based on DELF levels
- **Storage Layer**: Abstracted storage interface with in-memory implementation
- **API Routes**: RESTful endpoints for quiz operations
- **Error Handling**: Centralized error handling with proper HTTP status codes

### Database Schema
- **Users Table**: Basic user management with username/password
- **Quiz Types**: Support for A1, A2, B1, B2, C1 DELF levels
- **Question Structure**: Word, sentence context, multiple choice options
- **Results Tracking**: Score, timing, and detailed answer analysis

## Data Flow

1. **Quiz Initialization**: User selects DELF level from home page
2. **Question Generation**: Server generates 5 questions for selected level
3. **Interactive Quiz**: Client manages state, timer, and user interactions
4. **Answer Submission**: Real-time feedback with correct/incorrect indication
5. **Results Processing**: Client calculates final score and stores results
6. **Performance Review**: Detailed breakdown of answers and recommendations

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React 18 with TypeScript
- **Component Library**: Radix UI primitives via shadcn/ui
- **State Management**: TanStack Query for server state
- **Form Handling**: React Hook Form with Zod validation
- **Styling**: Tailwind CSS with custom design system
- **Icons**: Lucide React icon library

### Backend Dependencies
- **Database**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod for runtime type checking
- **Database Provider**: Neon serverless PostgreSQL
- **Session Store**: PostgreSQL session storage

### Development Tools
- **Build System**: Vite with React plugin
- **Type Checking**: TypeScript with strict mode
- **Code Quality**: ESLint and Prettier configuration
- **Development Server**: Hot reload with proxy setup

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: ESBuild compiles Express server to `dist/index.js`
3. **Database Migration**: Drizzle generates and runs migrations
4. **Asset Optimization**: Vite handles code splitting and optimization

### Environment Configuration
- **Database**: PostgreSQL connection via `DATABASE_URL`
- **Development**: Local development with hot reload
- **Production**: Optimized builds with static asset serving

### Deployment Architecture
- **Static Assets**: Frontend served from `dist/public`
- **API Server**: Express.js serving from `/api` routes
- **Database**: Neon serverless PostgreSQL
- **Session Storage**: PostgreSQL-backed sessions

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 07, 2025. Initial setup
- July 07, 2025. Added vocabulary tracking system with three learning states (not learned, just learned, very learned)
- July 07, 2025. Integrated Gemini AI for dynamic question generation based on user progress
- July 07, 2025. Added progress tracking page with detailed statistics and data import/export
- July 07, 2025. Implemented spaced repetition algorithm for vocabulary review
- July 07, 2025. Fixed HTML display bug in AI-generated sentences with improved prompt engineering and HTML cleanup
- July 07, 2025. Simplified learning system to 2 states: "Just Learned" and "Very Learned"
- July 07, 2025. Added variety in question types: French-to-English, English-to-French, and French fill-in-the-blank
- July 07, 2025. Enhanced quiz results page with navigation buttons to Progress and Home pages