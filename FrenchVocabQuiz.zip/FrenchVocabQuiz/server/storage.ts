import { GoogleGenerativeAI } from "@google/generative-ai";
import { users, type User, type InsertUser, type QuizQuestion, type DelLevel, type VocabularyItem } from "@shared/schema";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  generateQuizQuestions(level: DelLevel): Promise<QuizQuestion[]>;
  generateAIQuizQuestions(level: DelLevel, reviewWords?: VocabularyItem[]): Promise<QuizQuestion[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async generateQuizQuestions(level: DelLevel): Promise<QuizQuestion[]> {
    const vocabularyData = this.getVocabularyByLevel(level);
    const selectedWords = this.getRandomWords(vocabularyData, 5);
    
    return selectedWords.map(wordData => ({
      word: this.cleanHtml(wordData.word),
      sentence: this.cleanHtml(wordData.sentence),
      question: `What does "${wordData.word}" mean in this context?`,
      options: this.shuffleArray([wordData.meaning, ...wordData.distractors].map(opt => this.cleanHtml(opt))),
      answer: this.cleanHtml(wordData.meaning),
      level: level,
      type: "french_to_english" as const,
    }));
  }

  async generateAIQuizQuestions(level: DelLevel, reviewWords?: VocabularyItem[]): Promise<QuizQuestion[]> {
    if (!process.env.GEMINI_API_KEY) {
      // Fallback to static questions if no API key
      return this.generateQuizQuestions(level);
    }

    try {
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      
      let prompt = `You are a French vocabulary quiz generator specialized in DELF exams (A1 to C1 levels). Generate exactly 5 multiple-choice questions for DELF ${level} level with varied question types.`;

      if (reviewWords && reviewWords.length > 0) {
        const reviewList = reviewWords.map(w => `"${w.word}" (${w.meaning})`).join(", ");
        prompt += `\n\nInclude these vocabulary words for review: ${reviewList}. Generate 2-3 questions from these review words and 2-3 new words appropriate for ${level} level.`;
      } else {
        prompt += `\n\nGenerate 5 new vocabulary words appropriate for DELF ${level} level.`;
      }

      prompt += `\n\nQuestion Types (mix these):
1. French to English: "What does [French word] mean?"
2. English to French: "How do you say [English word] in French?"
3. French fill-in-the-blank: "Complete the sentence: [sentence with blank]"

Your output must be in JSON format. Each question should include:
- A vocabulary word in French (target word)
- A sentence showing the word in context (no HTML tags)
- Question type and appropriate options
- 1 correct answer and 3 wrong but plausible distractors

The JSON output format:
[
  {
    "word": "embouteillage",
    "sentence": "Il y a un embouteillage sur l'autoroute.",
    "question": "What does 'embouteillage' mean in this context?",
    "options": ["traffic jam", "bottle", "accident", "parking"],
    "answer": "traffic jam",
    "level": "${level}",
    "type": "french_to_english"
  },
  {
    "word": "fatigué",
    "sentence": "Après une longue journée, je suis très ____.",
    "question": "Complete the sentence with the correct French word:",
    "options": ["fatigué", "content", "rapide", "grand"],
    "answer": "fatigué",
    "level": "${level}",
    "type": "french_fill_blank"
  }
]

CRITICAL RULES:
- NEVER use HTML tags like <strong>, <em>, <b>, <i> in any text
- Use ONLY plain text in sentences and questions
- Mix question types: 2 french_to_english, 2 english_to_french, 1 french_fill_blank
- The difficulty of vocabulary must match the chosen level (${level})
- Do not repeat words in the same batch
- Make distractors realistic and appropriate for the level
- Provide exactly 5 questions
- Return only valid JSON, no additional text

EXAMPLE of correct format (no HTML):
{
  "word": "ambiguité",
  "sentence": "L'ambiguité de sa réponse a semé le doute.",
  "question": "What does 'ambiguité' mean in this context?",
  "options": ["ambiguity", "precision", "clarity", "simplicity"],
  "answer": "ambiguity",
  "level": "${level}",
  "type": "french_to_english"
}`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Clean the response to extract just the JSON
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        throw new Error("No valid JSON found in response");
      }
      
      const questions = JSON.parse(jsonMatch[0]);
      
      // Validate and ensure proper format, removing any HTML tags
      return questions.map((q: any) => ({
        word: this.cleanHtml(q.word),
        sentence: this.cleanHtml(q.sentence),
        question: this.cleanHtml(q.question),
        options: this.shuffleArray(q.options.map((opt: string) => this.cleanHtml(opt))),
        answer: this.cleanHtml(q.answer),
        level: level,
        type: q.type || "french_to_english",
      }));

    } catch (error) {
      console.error("Error generating AI questions:", error);
      // Fallback to static questions
      return this.generateQuizQuestions(level);
    }
  }

  private getVocabularyByLevel(level: DelLevel) {
    const vocabulary = {
      A1: [
        { word: "bonjour", sentence: "Bonjour, comment allez-vous?", meaning: "hello", distractors: ["goodbye", "thank you", "please"] },
        { word: "merci", sentence: "Merci beaucoup pour votre aide.", meaning: "thank you", distractors: ["excuse me", "hello", "goodbye"] },
        { word: "au revoir", sentence: "Au revoir, à bientôt!", meaning: "goodbye", distractors: ["hello", "thank you", "excuse me"] },
        { word: "oui", sentence: "Oui, je parle français.", meaning: "yes", distractors: ["no", "maybe", "always"] },
        { word: "non", sentence: "Non, je ne comprends pas.", meaning: "no", distractors: ["yes", "maybe", "never"] },
        { word: "s'il vous plaît", sentence: "Un café, s'il vous plaît.", meaning: "please", distractors: ["thank you", "excuse me", "hello"] },
        { word: "excusez-moi", sentence: "Excusez-moi, où est la gare?", meaning: "excuse me", distractors: ["thank you", "hello", "goodbye"] },
        { word: "eau", sentence: "Je voudrais un verre d'eau.", meaning: "water", distractors: ["wine", "coffee", "milk"] },
        { word: "pain", sentence: "Je mange du pain tous les matins.", meaning: "bread", distractors: ["cake", "cheese", "butter"] },
        { word: "maison", sentence: "Ma maison est très grande.", meaning: "house", distractors: ["car", "office", "school"] },
      ],
      A2: [
        { word: "rendez-vous", sentence: "J'ai un rendez-vous chez le médecin.", meaning: "appointment", distractors: ["meeting place", "date", "schedule"] },
        { word: "quartier", sentence: "J'habite dans un quartier calme.", meaning: "neighborhood", distractors: ["apartment", "street", "building"] },
        { word: "courses", sentence: "Je dois faire les courses au supermarché.", meaning: "shopping", distractors: ["running", "racing", "lessons"] },
        { word: "nouvel", sentence: "J'ai acheté un nouvel ordinateur.", meaning: "new", distractors: ["old", "expensive", "modern"] },
        { word: "emploi", sentence: "Il cherche un emploi dans l'informatique.", meaning: "job", distractors: ["hobby", "skill", "education"] },
        { word: "voyage", sentence: "Nous préparons un voyage en Italie.", meaning: "trip", distractors: ["vacation", "adventure", "journey"] },
        { word: "santé", sentence: "La santé est très importante.", meaning: "health", distractors: ["wealth", "happiness", "safety"] },
        { word: "environnement", sentence: "Il faut protéger l'environnement.", meaning: "environment", distractors: ["government", "society", "community"] },
        { word: "circulation", sentence: "La circulation est dense ce matin.", meaning: "traffic", distractors: ["movement", "rotation", "flow"] },
        { word: "formation", sentence: "Elle suit une formation professionnelle.", meaning: "training", distractors: ["education", "creation", "development"] },
      ],
      B1: [
        { word: "embouteillage", sentence: "Il y a un embouteillage sur l'autoroute.", meaning: "traffic jam", distractors: ["bottle", "accident", "parking"] },
        { word: "réussir", sentence: "Il va réussir son examen.", meaning: "to succeed", distractors: ["to fail", "to try", "to finish"] },
        { word: "développer", sentence: "Cette entreprise veut développer ses activités.", meaning: "to develop", distractors: ["to discover", "to distribute", "to decide"] },
        { word: "améliorer", sentence: "Nous devons améliorer nos services.", meaning: "to improve", distractors: ["to change", "to repair", "to increase"] },
        { word: "comportement", sentence: "Son comportement est exemplaire.", meaning: "behavior", distractors: ["character", "attitude", "personality"] },
        { word: "conséquence", sentence: "Quelle est la conséquence de cette décision?", meaning: "consequence", distractors: ["cause", "reason", "result"] },
        { word: "efficace", sentence: "Cette méthode est très efficace.", meaning: "efficient", distractors: ["effective", "easy", "simple"] },
        { word: "précis", sentence: "Il faut être précis dans ses explications.", meaning: "precise", distractors: ["clear", "exact", "specific"] },
        { word: "profiter", sentence: "Il faut profiter de cette occasion.", meaning: "to take advantage", distractors: ["to benefit", "to enjoy", "to use"] },
        { word: "éviter", sentence: "Il faut éviter les erreurs.", meaning: "to avoid", distractors: ["to prevent", "to escape", "to ignore"] },
      ],
      B2: [
        { word: "néanmoins", sentence: "Il pleut, néanmoins nous sortirons.", meaning: "nevertheless", distractors: ["however", "therefore", "meanwhile"] },
        { word: "davantage", sentence: "Il faut travailler davantage.", meaning: "more", distractors: ["better", "harder", "longer"] },
        { word: "désormais", sentence: "Désormais, nous utiliserons cette méthode.", meaning: "from now on", distractors: ["previously", "meanwhile", "afterwards"] },
        { word: "auparavant", sentence: "Auparavant, les choses étaient différentes.", meaning: "before", distractors: ["afterwards", "currently", "recently"] },
        { word: "accomplir", sentence: "Il a accompli une tâche difficile.", meaning: "to accomplish", distractors: ["to achieve", "to complete", "to perform"] },
        { word: "susciter", sentence: "Cette décision va susciter des débats.", meaning: "to arouse", distractors: ["to cause", "to provoke", "to create"] },
        { word: "aboutir", sentence: "Ces négociations vont aboutir à un accord.", meaning: "to lead to", distractors: ["to result in", "to end up", "to conclude"] },
        { word: "contraindre", sentence: "Les circonstances nous contraignent à partir.", meaning: "to force", distractors: ["to oblige", "to compel", "to require"] },
        { word: "prévaloir", sentence: "Cette opinion prévaut dans la société.", meaning: "to prevail", distractors: ["to dominate", "to exist", "to appear"] },
        { word: "entraver", sentence: "Ne laissez pas la peur entraver vos projets.", meaning: "to hinder", distractors: ["to block", "to stop", "to prevent"] },
      ],
      C1: [
        { word: "exacerber", sentence: "Cette mesure ne fait qu'exacerber les tensions.", meaning: "to exacerbate", distractors: ["to escalate", "to intensify", "to worsen"] },
        { word: "péjoratif", sentence: "Il a utilisé un terme péjoratif.", meaning: "pejorative", distractors: ["negative", "critical", "derogatory"] },
        { word: "prérogative", sentence: "C'est la prérogative du directeur.", meaning: "prerogative", distractors: ["privilege", "right", "authority"] },
        { word: "perpétuer", sentence: "Il faut perpétuer ces traditions.", meaning: "to perpetuate", distractors: ["to maintain", "to continue", "to preserve"] },
        { word: "corroborer", sentence: "Ces faits corroborent sa version.", meaning: "to corroborate", distractors: ["to confirm", "to support", "to verify"] },
        { word: "circonvenir", sentence: "Il a tenté de circonvenir le règlement.", meaning: "to circumvent", distractors: ["to bypass", "to avoid", "to evade"] },
        { word: "insidieux", sentence: "Ce poison agit de manière insidieuse.", meaning: "insidious", distractors: ["subtle", "hidden", "treacherous"] },
        { word: "ubiquité", sentence: "Il semble avoir le don d'ubiquité.", meaning: "ubiquity", distractors: ["omnipresence", "universality", "everywhere"] },
        { word: "véhément", sentence: "Il a protesté de manière véhémente.", meaning: "vehement", distractors: ["passionate", "intense", "forceful"] },
        { word: "prépondérant", sentence: "Il joue un rôle prépondérant dans cette affaire.", meaning: "predominant", distractors: ["important", "major", "decisive"] },
      ],
    };

    return vocabulary[level] || vocabulary.B1;
  }

  private getRandomWords(words: any[], count: number) {
    const shuffled = [...words].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }

  private shuffleArray<T>(array: T[]): T[] {
    const result = [...array];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  private cleanHtml(text: string): string {
    if (!text) return text;
    // Remove all HTML tags and decode HTML entities
    return text
      .replace(/<[^>]*>/g, '')
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ')
      .trim();
  }
}

export const storage = new MemStorage();
