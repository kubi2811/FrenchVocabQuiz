import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { vocabularyItemSchema } from "@shared/schema";

const generateQuizSchema = z.object({
  level: z.enum(["A1", "A2", "B1", "B2", "C1"]),
  useAI: z.boolean().optional().default(false),
  reviewWords: z.array(vocabularyItemSchema).optional(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Generate quiz questions for a specific level
  app.post("/api/quiz/generate", async (req, res) => {
    try {
      const { level, useAI, reviewWords } = generateQuizSchema.parse(req.body);
      
      let questions;
      if (useAI) {
        questions = await storage.generateAIQuizQuestions(level, reviewWords);
      } else {
        questions = await storage.generateQuizQuestions(level);
      }
      
      res.json({ questions });
    } catch (error) {
      console.error("Error generating quiz:", error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to generate quiz questions" 
      });
    }
  });

  // Get a random level
  app.get("/api/quiz/random-level", async (req, res) => {
    try {
      const levels = ["A1", "A2", "B1", "B2", "C1"];
      const randomLevel = levels[Math.floor(Math.random() * levels.length)];
      res.json({ level: randomLevel });
    } catch (error) {
      console.error("Error getting random level:", error);
      res.status(500).json({ message: "Failed to get random level" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
